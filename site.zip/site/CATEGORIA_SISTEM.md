# 📊 Sistem de Categorii PricePilot

## Categoria Principală: TELEFOANE MOBILE 📱
Produse care pot fi comparate între ele:
- **Smartphone-uri** (page: `smartphone-uri.html`) - 6 produse
  - Samsung Galaxy S24 Ultra
  - iPhone 15 Pro Max
  - Xiaomi 14 Ultra
  - Google Pixel 8 Pro
  - OnePlus 12
  - Huawei Mate 60 Pro
  
- **Telefoane Simple** (page: `telefoane-simple.html`) - 3 produse
  - Nokia 110
  - Samsung GT-E1215
  - Alcatel 10.40

**Total: 9 produse mobile phone care se pot compara între ele** ✓

---

## Categoria: TABLETE 📟
Produse care pot fi comparate între ele:
- iPad Pro 12.9"
- Samsung Galaxy Tab S9
- iPad Air 10.9"
- Samsung Galaxy Tab A8

**Total: 4 tablete** ✓

---

## Categoria: LAPTOPURI 💻
Subcategorii care pot fi comparate în cadrul lor:

### Gaming Laptops (page: `laptopuri-gaming.html`) - 3 produse
- ASUS ROG Strix G15
- MSI Raider GE78
- Razer Blade 16

### Business Laptops (page: `laptopuri-business.html`) - 3 produse
- Dell Latitude 5420
- HP EliteBook 860
- Lenovo ThinkPad X1 Carbon

**Gaming laptops se pot compara între ele**
**Business laptops se pot compara între ele**
⚠️ **NU se pot compara laptopuri gaming cu laptopuri business**

---

## Categoria: CALCULATOARE DESKTOP 🖥️
Produse care pot fi comparate între ele:
- PC Gaming High-End
- PC Office
- Desktop Budget

**Total: 3 calculatoare desktop** ✓

---

## Categoria: TELEVIZOARE 📺
Produse care pot fi comparate între ele:
- Samsung UE55DU8000UXUA
- LG OLED 65"

**Total: 2 televizoare** ✓

---

## Categoria: CĂȘTI 🎧
Produse care pot fi comparate între ele:
- Sony WH-1000XM4 (din Audio section)
- Căști In-Ear diverses (din Accesorii Telefoane)

**Total: 2 căști** ✓

---

## Categoria: AUDIO SYSTEMS 🔊
- Soundbar Samsung 5.1 HW-Q800C

---

## Categoria: COMPONENTE PC 🔧
Subcategorii care pot fi comparate în cadrul lor:
- **Procesoare (CPU)** - 1 produs
- **Memorie RAM** - 1 produs
- **Stocare (SSD/HDD)** - 1 produs
- **Surse Alimentare (PSU)** - 1 produs
- **Sisteme Racire** - 1 produs

**Toate componentele PC pot fi comparate între ele** ✓

---

## Categoria: ACCESORII TELEFOANE 🎁
Produse care pot fi comparate între ele:
- Huse & Protecții
- Încărcătoare
- Cabluri & Adaptori
- Ecrane & Folii
- Carduri Memorie

**Total: 5 accesorii** ✓

---

## 🚀 Reguli de Comparație

| Dintre | Pot compara | Status |
|------|-----------|--------|
| Smartphones + Simple Phones | ✓ | Permis |
| Tablete + Tablete | ✓ | Permis |
| Gaming Laptops + Gaming Laptops | ✓ | Permis |
| Business Laptops + Business Laptops | ✓ | Permis |
| Gaming Laptops + Business Laptops | ❌ | INTERZIS |
| Desktop + Desktop | ✓ | Permis |
| Televizor + Televizor | ✓ | Permis |
| Căști + Căști | ✓ | Permis |
| Procesoare + Procesoare | ✓ | Permis |
| Accesorii telefoane + Accesorii telefoane | ✓ | Permis |
| **Telefon + Laptop** | ❌ | INTERZIS |
| **Tablet + Telefon** | ❌ | INTERZIS |
| **Căști + Telefon** | ❌ | INTERZIS |

---

## 📝 Mapare Interna JavaScript

```javascript
COMPARISON_GROUPS = {
    'mobile-phones': ['smartphones', 'phones', 'mobile-phones'],
    'tablets': ['tablets'],
    'laptops': ['laptops', 'gaming-laptops', 'business-laptops'],
    'desktops': ['desktops', 'gaming-pcs', 'workstations'],
    'headphones': ['headphones', 'earbuds', 'speakers'],
    'audio': ['audio', 'soundbars', 'speakers'],
    'tv': ['tv', 'televisions'],
    'accessories-mobile': ['accessories', 'phone-accessories', 'tablet-accessories'],
    'components': ['components', 'cpu', 'gpu', 'ram', 'storage', 'psu', 'cooling']
}
```

---

## ✅ Validare Implementata

Când utilizatorul încearcă să adauge un produs la comparație:
1. Se extrage categoria produsului: `data-category="..."`
2. Se determină grupul de comparație al acestui produs
3. Se compară cu grupul de comparație al produselor deja în lista
4. Dacă sunt în **același grup** ✓ → Produs adăugat
5. Dacă sunt în **grupuri diferite** ❌ → Mesaj de eroare

**Limita: Maximum 4 produse per comparație**

---

## 📍 Unde sunt definite categoriile?

Toate produsele au atributul `data-category="..."` în elementul `.product-card`:

```html
<div class="product-card" data-category="mobile-phones">
  <!-- produs -->
</div>
```

Validarea se face în `main.js` folosind funcțiile:
- `getComparisonGroup(category)` - obține grupul comparației
- `areCompatibleForComparison(cat1, cat2)` - verifică compatibilitate

---

Creat: 23 aprilie 2026
Sistem: PricePilot - Platforma de Comparare
