// PricePilot - JavaScript pentru funcționalități interactive
document.addEventListener('DOMContentLoaded', function() {

    // Sistem de comparație produse
    let productsToCompare = JSON.parse(localStorage.getItem('pricePilotCompare')) || [];

    // Mapping de categorii compatibile pentru comparație
    const COMPARISON_GROUPS = {
        'mobile-phones': ['smartphones', 'phones', 'mobile-phones'],
        'tablets': ['tablets'],
        'laptops': ['laptops', 'gaming-laptops', 'business-laptops'],
        'desktops': ['desktops', 'gaming-pcs', 'workstations'],
        'headphones': ['headphones', 'earbuds', 'speakers'],
        'audio': ['audio', 'soundbars', 'speakers'],
        'tv': ['tv', 'televisions'],
        'accessories-mobile': ['accessories', 'phone-accessories', 'tablet-accessories'],
        'components': ['components', 'cpu', 'gpu', 'ram', 'storage', 'psu', 'cooling'],
        'mens-clothing': ['mens-clothing'],
        'womens-clothing': ['womens-clothing'],
        'footwear': ['footwear'],
        'fashion-accessories': ['fashion-accessories'],
        'gaming-consoles': ['gaming-consoles'],
        'monitors': ['monitors']
    };

    // Mapping invers: categoria -> grupul de comparație
    const CATEGORY_TO_GROUP = {};
    Object.entries(COMPARISON_GROUPS).forEach(([group, categories]) => {
        categories.forEach(cat => {
            CATEGORY_TO_GROUP[cat] = group;
        });
    });

    // Mapping de nume prietenoase pentru categorii
    const CATEGORY_NAMES = {
        'smartphones': 'Smartphone-uri',
        'phones': 'Telefoane Simple',
        'mobile-phones': 'Telefoane Mobile',
        'tablets': 'Tablete',
        'laptops': 'Laptopuri',
        'gaming-laptops': 'Laptopuri Gaming',
        'business-laptops': 'Laptopuri Business',
        'desktops': 'Calculatoare Desktop',
        'gaming-pcs': 'PC-uri Gaming',
        'workstations': 'Workstations',
        'headphones': 'Căști',
        'earbuds': 'Casti In-Ear',
        'speakers': 'Difuzoare',
        'audio': 'Sisteme Audio',
        'soundbars': 'Soundbar-uri',
        'tv': 'Televizoare',
        'televisions': 'Televizoare',
        'accessories': 'Accesorii',
        'phone-accessories': 'Accesorii Telefoane',
        'tablet-accessories': 'Accesorii Tablete',
        'accessories-mobile': 'Accesorii Mobile',
        'components': 'Componente PC',
        'cpu': 'Procesoare',
        'gpu': 'Plăci Video',
        'ram': 'Memorie RAM',
        'storage': 'Stocare',
        'psu': 'Surse Alimentare',
        'cooling': 'Sisteme Racire',
        'mens-clothing': 'Îmbrăcăminte Bărbați',
        'womens-clothing': 'Îmbrăcăminte Femei',
        'footwear': 'Încălțăminte',
        'fashion-accessories': 'Accesorii Modă',
        'gaming-consoles': 'Console Gaming',
        'monitors': 'Monitoare'
    };

    // Funcție pentru a obține grupul de comparație al unei categorii
    function getComparisonGroup(category) {
        return CATEGORY_TO_GROUP[category] || category;
    }

    // Funcție pentru a verifica dacă două categorii sunt compatibile pentru comparație
    function areCompatibleForComparison(category1, category2) {
        // Permite comparația tuturor produselor între ele
        return true;
    }

    // Funcție pentru filtrele de căutare
    function initializeFilters() {
        const filterButtons = document.querySelectorAll('.category-btn');
        const productCards = document.querySelectorAll('.product-card[data-category]');

        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                const category = this.getAttribute('data-category');

                // Remove active class from all buttons
                filterButtons.forEach(btn => btn.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');

                // Filter products
                productCards.forEach(card => {
                    if (category === 'all' || card.getAttribute('data-category') === category) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }

    // Funcție pentru căutarea de produse
    function initializeSearch() {
        const searchInputs = document.querySelectorAll('input[type="text"][placeholder*="Caută"]');

        searchInputs.forEach(input => {
            input.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const productCards = document.querySelectorAll('.product-card');

                productCards.forEach(card => {
                    const productName = card.querySelector('h3').textContent.toLowerCase();
                    const productDesc = card.querySelector('.product-specs') ?
                        card.querySelector('.product-specs').textContent.toLowerCase() : '';

                    if (productName.includes(searchTerm) || productDesc.includes(searchTerm)) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }

    // Funcție pentru a extrage informațiile produsului
    function extractProductInfo(card) {
        const title = card.querySelector('h3').textContent.trim();
        const image = card.querySelector('img').src;
        const price = card.querySelector('.product-price').textContent.trim();
        const category = card.getAttribute('data-category') || 'unknown';
        const specs = {};

        // Extrage specificațiile din product-specs
        const specElements = card.querySelectorAll('.product-specs p');
        specElements.forEach(spec => {
            const text = spec.textContent;
            const colonIndex = text.indexOf(':');
            if (colonIndex > -1) {
                const key = text.substring(0, colonIndex).replace(/<strong>/g, '').replace(/<\/strong>/g, '').trim();
                const value = text.substring(colonIndex + 1).trim();
                specs[key] = value;
            }
        });

        return {
            id: title.toLowerCase().replace(/\s+/g, '-'),
            title: title,
            image: image,
            price: price,
            category: category,
            specs: specs,
            url: window.location.href
        };
    }

    // Funcție pentru a actualiza starea butoanelor de comparație
    function updateCompareButtons() {
        const compareButtons = document.querySelectorAll('.btn-outline');

        compareButtons.forEach(button => {
            if (button.textContent.includes('Compară') || button.textContent.includes('Elimină din comparație')) {
                const card = button.closest('.product-card');
                const productId = extractProductInfo(card).id;
                const isSelected = productsToCompare.some(p => p.id === productId);

                if (isSelected) {
                    button.textContent = 'Elimină din comparație';
                    button.classList.add('selected');
                } else {
                    button.textContent = 'Compară';
                    button.classList.remove('selected');
                }
            }
        });
    }

    // Funcție pentru a crea modalul de comparație
    function createCompareModal() {
        // Șterge modalul vechi dacă există
        const existingModal = document.querySelector('.compare-modal');
        if (existingModal) {
            existingModal.remove();
        }

        const modal = document.createElement('div');
        modal.className = 'compare-modal';
        modal.innerHTML = `
            <div class="compare-modal-overlay"></div>
            <div class="compare-modal-content">
                <div class="compare-modal-header">
                    <h2>Compară Produse (${productsToCompare.length}/4)</h2>
                    <button class="compare-modal-close">&times;</button>
                </div>
                <div class="compare-modal-body">
                    <div class="compare-products-grid"></div>
                </div>
                <div class="compare-modal-footer">
                    <button class="btn btn-outline clear-compare">Șterge toate</button>
                    <button class="btn btn-primary view-full-compare">Vezi comparație completă</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        // Event listeners pentru modal
        modal.querySelector('.compare-modal-close').addEventListener('click', () => {
            modal.style.display = 'none';
        });

        modal.querySelector('.compare-modal-overlay').addEventListener('click', () => {
            modal.style.display = 'none';
        });

        modal.querySelector('.clear-compare').addEventListener('click', () => {
            productsToCompare = [];
            localStorage.setItem('pricePilotCompare', JSON.stringify(productsToCompare));
            updateCompareButtons();
            updateCompareModal();
        });

        modal.querySelector('.view-full-compare').addEventListener('click', () => {
            showFullComparison();
        });
    }

    // Funcție pentru a actualiza conținutul modalului
    function updateCompareModal() {
        const modal = document.querySelector('.compare-modal');
        if (!modal) return;

        const grid = modal.querySelector('.compare-products-grid');
        const header = modal.querySelector('.compare-modal-header h2');

        // Actualizează titlul cu numărul de produse
        header.textContent = `Compară Produse (${productsToCompare.length}/4)`;

        if (productsToCompare.length === 0) {
            grid.innerHTML = '<p class="no-products">Nu ai selectat niciun produs pentru comparație.</p>';
            return;
        }

        let html = '';
        productsToCompare.forEach(product => {
            html += `
                <div class="compare-product-card">
                    <img src="${product.image}" alt="${product.title}" class="compare-product-image">
                    <h4>${product.title}</h4>
                    <p class="compare-price">${product.price}</p>
                    <button class="btn btn-sm remove-compare" data-product-id="${product.id}">Elimină</button>
                </div>
            `;
        });

        grid.innerHTML = html;

        // Event listeners pentru butoanele de eliminare
        grid.querySelectorAll('.remove-compare').forEach(btn => {
            btn.addEventListener('click', function() {
                const productId = this.getAttribute('data-product-id');
                productsToCompare = productsToCompare.filter(p => p.id !== productId);
                localStorage.setItem('pricePilotCompare', JSON.stringify(productsToCompare));
                updateCompareButtons();
                updateCompareModal();
            });
        });
    }

    // Funcție pentru a afișa comparația completă
    function showFullComparison() {
        if (productsToCompare.length < 2) {
            alert('Selectează cel puțin 2 produse pentru comparație!');
            return;
        }

        // Creează o pagină nouă pentru comparație
        const compareWindow = window.open('', '_blank');
        let html = `
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comparație Produse - PricePilot</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .comparison-page { padding: 20px; }
        .comparison-header { text-align: center; margin-bottom: 30px; }
        .comparison-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .comparison-table th, .comparison-table td {
            border: 1px solid #ddd; padding: 12px; text-align: left; vertical-align: top;
        }
        .comparison-table th { background-color: #f8f9fa; font-weight: bold; }
        .product-image-cell { text-align: center; }
        .product-image-cell img { max-width: 100px; height: auto; }
        .spec-highlight { background-color: #e3f2fd; }
        .back-button { margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container comparison-page">
        <button class="btn btn-outline back-button" onclick="window.close()">← Înapoi</button>
        <div class="comparison-header">
            <h1>Comparație Detaliată</h1>
            <p>Compară specificațiile produselor selectate</p>
        </div>
        <div class="table-responsive">
            <table class="comparison-table">
                <thead>
                    <tr>
                        <th>Specificație</th>`;

        // Adaugă header pentru fiecare produs
        productsToCompare.forEach(product => {
            html += `<th>${product.title}</th>`;
        });
        html += `</tr></thead><tbody>`;

        // Colectează toate specificațiile disponibile
        const allSpecs = new Set();
        productsToCompare.forEach(product => {
            Object.keys(product.specs).forEach(spec => allSpecs.add(spec));
        });

        // Adaugă rânduri pentru fiecare specificație
        Array.from(allSpecs).forEach(spec => {
            html += `<tr><td class="spec-highlight"><strong>${spec}</strong></td>`;
            productsToCompare.forEach(product => {
                const value = product.specs[spec] || '-';
                html += `<td>${value}</td>`;
            });
            html += `</tr>`;
        });

        // Adaugă rând pentru preț
        html += `<tr><td class="spec-highlight"><strong>Preț</strong></td>`;
        productsToCompare.forEach(product => {
            html += `<td><strong>${product.price}</strong></td>`;
        });
        html += `</tr>`;

        html += `
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>`;

        compareWindow.document.write(html);
        compareWindow.document.close();
    }

    // Funcție pentru toast messages
    function showToast(message) {
        let toast = document.querySelector('.toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.className = 'toast';
            toast.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: #4CAF50;
                color: white;
                padding: 12px 20px;
                border-radius: 4px;
                z-index: 10000;
                display: none;
            `;
            document.body.appendChild(toast);
        }

        toast.textContent = message;
        toast.style.display = 'block';

        setTimeout(() => {
            toast.style.display = 'none';
        }, 3000);
    }

    // Funcție pentru butoanele de acțiune
    function initializeButtons() {
        const actionButtons = document.querySelectorAll('.btn');
        console.log(`✓ Găsite ${actionButtons.length} butoane`);

        actionButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                //e.preventDefault();
                const buttonText = this.textContent.trim();
                console.log(`🔘 Buton clicked: "${buttonText}"`);

                if (buttonText.includes('Vezi oferte')) {
                    alert('Funcționalitate în dezvoltare - Vezi oferte detaliate');
                } else if (buttonText.includes('Compară') || buttonText.includes('Elimină din comparație')) {
                    console.log('📊 Comparație btn clicked!');
                    
                    try {
                        const card = this.closest('.product-card');
                        if (!card) {
                            console.error('❌ .product-card not found!');
                            return;
                        }
                        
                        const product = extractProductInfo(card);
                        console.log('📦 Product:', product);
                        
                        const productCategory = card.getAttribute('data-category');
                        console.log(`📂 Category: ${productCategory}`);

                        const existingIndex = productsToCompare.findIndex(p => p.id === product.id);

                        if (existingIndex > -1) {
                            productsToCompare.splice(existingIndex, 1);
                            showToast('Produs eliminat din comparație');
                        } else {
                            if (productsToCompare.length >= 4) {
                                alert('⚠️ Poți compara maximum 4 produse simultan!');
                                return;
                            }

                            product.category = productCategory;
                            productsToCompare.push(product);
                            console.log(`✓ Added! Total: ${productsToCompare.length}/4`);
                            showToast(`✓ Produs adăugat (${productsToCompare.length}/4)`);
                        }

                        localStorage.setItem('pricePilotCompare', JSON.stringify(productsToCompare));
                        updateCompareButtons();
                        createCompareModal();
                        updateCompareModal();
                        
                        const modal = document.querySelector('.compare-modal');
                        if (modal) {
                            modal.style.display = 'block';
                            console.log('✓ Modal displayed');
                        } else {
                            console.error('❌ Modal not found!');
                        }
                    } catch(err) {
                        console.error('❌ Error:', err);
                    }
                }
            });
        });
    }

    // Funcție pentru a obține numele categoriei în română
    function getCategoryName(category) {
        return CATEGORY_NAMES[category] || category;
    }

    // Funcție pentru filtrele de selecție
    function initializeSelectFilters() {
        const selectFilters = document.querySelectorAll('select');

        selectFilters.forEach(select => {
            select.addEventListener('change', function() {
                const filterType = this.id.replace('-filter', '');
                const filterValue = this.value;

                if (filterValue) {
                    console.log(`Filtru aplicat: ${filterType} = ${filterValue}`);
                    // Aici poți adăuga logica de filtrare reală
                }
            });
        });
    }

    // Inițializare tuturor funcționalităților
    initializeFilters();
    initializeSearch();
    initializeButtons();
    initializeSelectFilters();
    updateCompareButtons();

    // Mesaj de bun venit
    console.log('🚀 PricePilot - Site încărcat cu succes!');
    console.log('💡 Funcționalități disponibile: căutare, filtre, comparație');
    console.log(`📊 Produse în comparație: ${productsToCompare.length}`);

});